//
//  ViewController.swift
//  Sample_use_SDK_IOS
//
//  Created by jean-luc camors on 08/04/2015.
//  Copyright (c) 2015 Orange Vallee. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {
	var delegate: AppDelegate
	@IBOutlet var versionLabel: UILabel!
	@IBOutlet var apiURLInput: UITextField!
	@IBOutlet var controlAutoAlert: UISegmentedControl!
	@IBOutlet var stopBtn: UIButton!
	@IBOutlet var startBtn: UIButton!
	@IBOutlet var activityIndicator: UIActivityIndicatorView!

	required init(coder aDecoder: NSCoder)
	{
		delegate = UIApplication.sharedApplication().delegate as! AppDelegate
		super.init(coder: aDecoder);
	}
	
	override func viewDidLoad() {
		super.viewDidLoad()
		// Do any additional setup after loading the view, typically from a nib.
		versionLabel.text				= OBVERSION
	}
	
	override func viewWillAppear(animated: Bool) {
		controlAutoAlert.selectedSegmentIndex	= delegate.autoAlert ? 0 : 1
		changeUI()
		super.viewWillAppear(animated)
	}
	
	
//	#pragma mark - private methods
	
	//	Change la visualisation de l'interface
	func changeUI() {
	
		var bStarted: Bool							= delegate.getStarted()
		startBtn.hidden								= bStarted
		stopBtn.hidden								= !bStarted
		
		if ( bStarted ) {
			var interval: NSTimeInterval			= 5
			activityIndicator.startAnimating()
			var timer								= NSTimer.scheduledTimerWithTimeInterval(interval, target: self, selector: Selector("verifyStartOBLE"), userInfo: nil, repeats: false)
		}
		else {
			activityIndicator.stopAnimating()
		}
	}
	
	//	Si la lib OBLE est bien demarrée, rien a faire.
	func verifyStartOBLE() {
		//	Si pas bien demarrée : retourne a l'etat Stop
		if ( !delegate.verifyStartOBLE() ) {
			changeUI()
		}
	}

	func textFieldShouldReturn(textField: UITextField ) -> Bool {
		textField.resignFirstResponder()
		return false
	}
	
	
//	#pragma mark - IBAction
	
	@IBAction func handleAutoAlerte( sender: AnyObject ) {
		var bAutoAlerte : Bool						= (controlAutoAlert.selectedSegmentIndex == 0 ? true : false )
		NSLog("handleAutoAlerte() %@", ( bAutoAlerte ? "YES" : "NO") );
		
		delegate.chgAutoAlert(bAutoAlerte)
		changeUI()
	}
	
	@IBAction func stopOBLE( sender: AnyObject ) {
		delegate.stopOBLE()
		changeUI()
	}
	
	@IBAction func startOBLE( sender: AnyObject ) {
		delegate.startOBLE()
		changeUI()
	}
	
	@IBAction func refreshConfig( sender: AnyObject ) {
		OrangeBeacon.update()
		changeUI()
	}

}

