//
//  Sample_use_SDK_IOS-Bridging-Header.h.h
//  Sample_use_SDK_IOS
//
//  Created by jean-luc camors on 08/04/2015.
//  Copyright (c) 2015 Orange Vallee. All rights reserved.
//

#ifndef Sample_use_SDK_IOS_Sample_use_SDK_IOS_Bridging_Header_h
#define Sample_use_SDK_IOS_Sample_use_SDK_IOS_Bridging_Header_h

#import <OrangeBLE/OrangeBeacon.h>
#import <OrangeBLE/OBConfig.h>


#endif
