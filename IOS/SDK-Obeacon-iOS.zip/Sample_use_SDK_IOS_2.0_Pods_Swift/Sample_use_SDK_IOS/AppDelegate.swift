//
//  AppDelegate.swift
//  Sample_use_SDK_IOS
//
//  Created by jean-luc camors on 09/04/2015.
//  Copyright (c) 2015 Orange Vallee. All rights reserved.
//

import UIKit
import CoreLocation

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate, UIAlertViewDelegate, CLLocationManagerDelegate {
	
	let UUID_BIDON:String					= "3D4F13B4-D1FD-4049-80E5-D3EDCC840B70"
	
	var window: UIWindow?
	var autoAlert: Bool						= true
	let askPermission: Bool					= false			//	Si on ne veut pas que le sdk demande les permissions : False
	var bStarted: Bool						= false
	var urlToOpen:String					= ""
	var lastActions:NSMutableDictionary		= NSMutableDictionary()
	var launchOptions:[NSObject : AnyObject]?
	var locationManager:CLLocationManager?
	var region:CLBeaconRegion?
	
	func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool {
		self.launchOptions					= launchOptions;
		
		// Si le SDK ne doit pas demander les permissions.
		if ( !askPermission ) {
			locationManager					= CLLocationManager()
			locationManager!.delegate		= self
		}
		
		//	Demarrage ou non de la lib OBLE ( si le location Manager ecoutait deja les Orange Beacon )
		if ( OrangeBeacon.isAlreadyMonitoredBeacon() ) {
			self.startOBLE()
		}
		
		return true
	}
	
	func application(application: UIApplication, performFetchWithCompletionHandler completionHandler: (UIBackgroundFetchResult) -> Void) {
		OrangeBeacon.applicationPerformFetchWithCompletionHandler(completionHandler)
	}
	
	func application(application: UIApplication, didReceiveLocalNotification notification: UILocalNotification) {
		NSLog("didReceiveLocalNotification() notification : %@", notification.alertBody! )
		
		if ( UIApplication.sharedApplication().applicationState != UIApplicationState.Active ) {
			NSLog("didReceiveLocalNotification() not UIApplicationStateActive !" )
			//	Reçoit l'action de la notif clické en background
			var userInfo:Dictionary					= notification.userInfo as Dictionary!
			if ( !userInfo.isEmpty && userInfo["ActionID"]?.length > 0 ) {
				let action: String					= userInfo["ActionID"] as! String
				NSLog("didReceiveLocalNotification() action : %@", action )
				if ( !action.isEmpty ) {
					let url:NSURL					= NSURL(string:action)!
					UIApplication.sharedApplication().openURL(url)
				}
				else {
					NSLog("didReceiveLocalNotification() action nulle !" )
				}
			}
			else {
				NSLog("didReceiveLocalNotification() Pas d'action !" )
			}
		}
		else if ( self.autoAlert ) {
			NSLog("didReceiveLocalNotification() autoAlert !" )
			OrangeBeacon.applicationDidReceiveLocalNotification(notification)
		}
	}

	
//	pragma mark - OrangeBeacon delegate
	
	func orangeBeaconLocationAuthorizationRefused() ->Void {
		NSLog("OrangeBeaconLocationAuthorizationRefused")
	}
	
	func orangeBeaconAlertTriggeredWithTitle( title:NSString, action:NSString, direction:NSString ) ->Bool {
		NSLog("orangeBeaconAlertTriggeredWithTitle() title : %@ action = %@ direction = %@", title, action, direction)
		
		if ( !self.autoAlert ) {
			if ( UIApplication.sharedApplication().applicationState != UIApplicationState.Active ) {
				NSLog("orangeBeaconAlertTriggeredWithTitle() not UIApplicationStateActive !" )
				let notification:UILocalNotification	= UILocalNotification()
				var userInfo:Dictionary			= [String: String]()
				userInfo["ActionID"]			= action as String

				notification.userInfo			= userInfo
				notification.alertAction		= action as String
				notification.alertBody			= String( format: "Custom Notification\n%@",title )
				UIApplication.sharedApplication().presentLocalNotificationNow(notification)
			}
			else {
				let titleAlert		= "Custom alert"
				
				// Here we can filter out unwanted messages, and manualy show alerts that we want.
				self.urlToOpen = action as String
				let alertView		= UIAlertView()
				
				alertView.addButtonWithTitle("Cancel")
				alertView.addButtonWithTitle("Ok")
				alertView.cancelButtonIndex	= 0
				alertView.title		= titleAlert
				alertView.message	= title as String
				alertView.delegate	= self
				
				if (action.length != 0) {
					let key:Int						= action.hash;
					lastActions.setObject(action, forKey: String(key))
					alertView.tag					= key
				}
				alertView.show()
			}
		}
		
		return self.autoAlert
	}
	
	
//	pragma mark - AlertView delegate

	func alertView(alertView: UIAlertView, clickedButtonAtIndex buttonIndex: Int) {
		NSLog("alertView clickedButtonAtIndex()" )
		let tag:Int									= alertView.tag
		if ( tag != 0 ) {
			let key:String								= String(tag)
			let action:NSString							= lastActions.objectForKey(key) as! NSString
			
			if (  action.length > 0 && buttonIndex != alertView.cancelButtonIndex ) {
				NSLog("alertView clickedButtonAtIndex() action = %@", action );
				let url:NSURL = NSURL(string: action as String)!
				UIApplication.sharedApplication().openURL(url)
			}
		
			lastActions.removeObjectForKey(key)
		}
	}
	
	
//	#pragma mark - Location manager
	
	func locationManager(manager: CLLocationManager!, didChangeAuthorizationStatus status: CLAuthorizationStatus) {
		let statusString:String
		switch (status) {
		case CLAuthorizationStatus.NotDetermined:
			statusString = "NotDetermined"
			break
		case CLAuthorizationStatus.Restricted:
			statusString = "Restricted"
			break
		case CLAuthorizationStatus.Denied:
			statusString = "Denied"
			break
		case CLAuthorizationStatus.AuthorizedAlways:
			statusString = "Authorized always"
			break
		case CLAuthorizationStatus.AuthorizedWhenInUse :
			statusString = "Authorized when in use"
			break
		default:
			break
		}
		
		NSLog("locationManager() New authorization status: %@", statusString)
		
		if ( NSFoundationVersionNumber > NSFoundationVersionNumber_iOS_7_1) {
			if (status == CLAuthorizationStatus.NotDetermined &&	manager.respondsToSelector(Selector("requestAlwaysAuthorization")) ) {
				manager.requestAlwaysAuthorization()
			}
		}
		else {
			// in iOS 7 -> status is NotDetermined even if the user authorized the app
			if (status == CLAuthorizationStatus.NotDetermined ) {
				//	demande de monitoring Bidon
				NSLog("locationManager() Demande de Monitoring UUID_BIDON = %@", UUID_BIDON);
				region					= CLBeaconRegion(proximityUUID: NSUUID(UUIDString: UUID_BIDON), identifier: "1")
				locationManager!.startMonitoringForRegion(region)
			}
		}
	}
	
	func locationManager( manager: CLLocationManager!, didFailWithError error:NSError ) {
		NSLog("locationManager() Error from location manager: %@", error)
	}
	
	func locationManager(manager: CLLocationManager!, didDetermineState state: CLRegionState, forRegion region: CLRegion!) {
		// only beacon
		if ( region.isKindOfClass(CLBeaconRegion.classForCoder()) ) {
			var beaconRegion: CLBeaconRegion	= region as! CLBeaconRegion
			NSLog("locationManager() Stop monitoring region : %@", beaconRegion.proximityUUID.UUIDString )
			locationManager!.stopMonitoringForRegion(region)
			locationManager!.delegate = nil
			locationManager = nil
		}
	}
	
	
//	#pragma mark - public methods
	
	func startOBLE() {
		if ( !bStarted ) {
			var application: UIApplication		= UIApplication.sharedApplication()
			if NSProcessInfo.instancesRespondToSelector(Selector("isOperatingSystemAtLeastVersion")) && NSProcessInfo().isOperatingSystemAtLeastVersion(NSOperatingSystemVersion(majorVersion: 8, minorVersion: 0, patchVersion: 0)) {
				if ( UIApplication.instancesRespondToSelector( Selector("registerUserNotificationSettings") ) ) {
					application.registerUserNotificationSettings(UIUserNotificationSettings(forTypes:UIUserNotificationType.Alert|UIUserNotificationType.Badge|UIUserNotificationType.Sound, categories:nil) )
				}
			}
			
			// identifiant d'accès API : login / passwd
			let login							= "YOUR_LOGIN_PARTNER"
			let passwd							= "YOUR_PASSWORD_PARTNER"

			let config: OBConfig				= OBConfig( login:login, password:passwd)
			
			config.logLevel						= Int32(NSIntegerMax)
			config.minUpdateInterval			= NSTimeInterval(15 * 60)			//INTERVAL_FIFTEEN_MINUTES
			
			config.minActionRepeatInterval		= 10
			config.notificationsWithSound		= true
			
			//	Demande les permissions de localisation (Popup) par le SDK ou non
			config.shouldAskPermission			= askPermission;
			
			OrangeBeacon.startWithConfig(config, application: application, options:launchOptions, delegate: autoAlert ? nil : self)
			
			
			//force update
			OrangeBeacon.update()
			bStarted							= true
		}
	}
	
	func stopOBLE() {
		OrangeBeacon.stop()
		bStarted								= false
	}
	
	func chgAutoAlert( bAutoAlert: Bool ) {
		autoAlert								= bAutoAlert
		
		if ( verifyStartOBLE() ) {
			stopOBLE()
		}
		
		startOBLE()
	}
	
	func getStarted() -> Bool {
		return bStarted
	}
	
	func verifyStartOBLE() -> Bool {
		bStarted								= OrangeBeacon.isStarted()
		return bStarted
	}
	
}
