## Getting started with the Orange Beacon SDK

Thank you for taking the time to test our Beacons in your iOS ecosystem.

The Orange Beacon SDK requires **CocoaPods** <http://cocoapods.org>. 
If it is not already installed on your Mac, please open 
the **Terminal** app and type the following command:  
` $ sudo gem install cocoapods`

With **Terminal** and from the `.../Sample_use_SDK_IOS/` directory, please type the following command:  
` $ pod install`

With **Xcode** (version 6+), please do the following:  

- open `Sample_use_SDK_IOS.xcworkspace`
- check that `libPods.a` has been added to the 'Linked Frameworks and Libraries' of target `Sample_use_SDK_IOS`, under the 'General' tab. Otherwise re-install `pod`
- add `OrangeBLE.framework` manually to these 'Linked Frameworks and Libraries'
- replace `YOUR_LOGIN_PARTNER` and `YOUR_PASSWORD_PARTNER` by your own credentials in file: `AppDelegate.m`. Those credentials can be found via your portal: <https://bo.beacon.orange.fr>.

Please use an **actual device** (e.g. iPhone 4s or later, iPad 2 or later, iPod touch 4 or later) for your tests, and not the Simulator.

Notice in AppDelegate.m :
autoAlert = YES	--> alerts are provided by the SDK Orange Beacon
autoAlert = NO	--> alerts are provided by your Orange Beacon delegate : - (BOOL) orangeBeaconAlertTriggeredWithTitle:(NSString *)title
									 action:(NSString *)action
								  direction:(NSString *)direction

askPermission = YES --> Popup for asking permission for localisation are provided by the SDK Orange Beacon.
askPermission = NO  --> Popup for asking permission for localisation are provided by your App.

If you have any question, comment or suggestion, please feel free to contact us at <support.dev@orange.com>
