//
//  ViewController.h
//  Sample_use_SDK_IOS
//
//  Created by jean-luc camors on 02/10/2014.
//  Copyright (c) 2014 Orange Vallee. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController < UITextFieldDelegate >

@property (strong, nonatomic) IBOutlet UILabel *versionLabel;
@property (strong, nonatomic) IBOutlet UITextField *apiURLInput;

@property (weak, nonatomic) IBOutlet UISegmentedControl *controlAutoAlert;
@property (weak, nonatomic) IBOutlet UIButton *stopBtn;
@property (weak, nonatomic) IBOutlet UIButton *startBtn;
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *activityIndicator;


- (IBAction)stopOBLE:(id)sender;
- (IBAction)refreshConfig:(id)sender;
- (IBAction)handleAutoAlerte:(id)sender;

@end

