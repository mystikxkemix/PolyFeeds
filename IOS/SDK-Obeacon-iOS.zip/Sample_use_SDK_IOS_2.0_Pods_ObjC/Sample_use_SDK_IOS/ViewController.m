//
//  ViewController.m
//  Sample_use_SDK_IOS
//
//  Created by jean-luc camors on 02/10/2014.
//  Copyright (c) 2014 Orange Vallee. All rights reserved.
//

#import "ViewController.h"
#import <OrangeBLE/OrangeBeacon.h>
#import "AppDelegate.h"
#import <CocoaLumberjack/DDLog.h>


@interface ViewController () 

@end

@implementation ViewController


- (void)viewDidLoad
{
	[super viewDidLoad];
	_versionLabel.text = [[NSString alloc] initWithFormat:@"v %@", OBVERSION];
}

-(void)viewWillAppear:(BOOL)animated {
	_controlAutoAlert.selectedSegmentIndex	= [[AppDelegate sharedAppDelegate] getAutoAlert] ? 0 : 1;
	
	[self changeUI];
	
	[super viewWillAppear:animated];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
	[textField resignFirstResponder];
	return NO;
}



#pragma mark - IBAction

- (IBAction)handleAutoAlerte:(id)sender {
	UISegmentedControl * segmentedControl	= (UISegmentedControl *)sender;
	BOOL bAutoAlerte						= (segmentedControl.selectedSegmentIndex == 0 ? YES : NO );
	NSLog(@"handleAutoAlerte() %@", ( bAutoAlerte ? @"YES" : @"NO") );
	
	[[AppDelegate sharedAppDelegate] setAutoAlert:bAutoAlerte];
	[self changeUI];
}

- (IBAction)stopOBLE:(id)sender
{
	[[AppDelegate sharedAppDelegate] stopOBLE];
	[self changeUI];
}

- (IBAction)startOBLE:(id)sender
{
	[[AppDelegate sharedAppDelegate] startOBLE];
	[self changeUI];
}

- (IBAction)refreshConfig:(id)sender
{
	[OrangeBeacon update];
	[self changeUI];
}


#pragma mark - private methods

//	Change la visualisation de l'interface
- (void) changeUI {
	
	BOOL bStarted							= [[AppDelegate sharedAppDelegate] getStarted];
	[_startBtn setHidden:bStarted];
	[_stopBtn setHidden:!bStarted];
	
	if (bStarted) {
		NSTimeInterval interval = 5;
		[_activityIndicator startAnimating];
		[self performSelector:@selector(verifyStartOBLE) withObject:nil afterDelay:interval];
	}
	else {
		[_activityIndicator stopAnimating];
	}
}

//	Si la lib OBLE est bien demarrée, rien a faire.
- (void) verifyStartOBLE {
	//	Si pas bien demarrée : retourne a l'etat Stop
	if ( ![[AppDelegate sharedAppDelegate] verifyStartOBLE]) {
		[self changeUI];
	}
}

@end
