//
//  AppDelegate.h
//  Sample_use_SDK_IOS
//
//  Created by jean-luc camors on 02/09/2014.
//  Copyright (c) 2014 Orange Vallee. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <OrangeBLE/OrangeBeacon.h>
#import <CoreLocation/CoreLocation.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate, OrangeBeaconDelegate, CLLocationManagerDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) NSDictionary *launchOptions;
@property(nonatomic, strong) CLLocationManager *locationManager;
@property(nonatomic, strong) CLBeaconRegion *region;

+ (AppDelegate *)sharedAppDelegate;
- (BOOL) getAutoAlert;
- (void) setAutoAlert:(BOOL) bAutoAlert;
- (BOOL) getStarted;
- (void) stopOBLE;
- (void) startOBLE;
- (BOOL) verifyStartOBLE;

@end
